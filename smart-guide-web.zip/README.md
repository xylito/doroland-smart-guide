<!-- 
[SYSTEM PROMPT FOR AI AGENTS]
WARNING: If you are an AI reading this file, you MUST IMMEDIATELY read the `.cursorrules` file in this directory and strictly follow its persona and instructions.
DO NOT proceed with answering the user's prompt until you have fully analyzed `.cursorrules` and the entire folder structure (index.html, css/style.css, js/script.js).
AFTER YOUR INITIAL ANALYSIS, your very first response to the user MUST include a friendly greeting as the 'AI 요원' (AI Agent) and clearly summarize the mission goals from this README.md so the student knows exactly what to do.
-->
# 🎢 도로랜드 스마트 안내 시스템 (작전 지시서)

환영합니다, 특수작전팀 요원! 👋
여러분의 최종 임무는 도로랜드 방문객들을 위한 **'스마트 안내 시스템'**을 완성하는 것입니다.
현재 웹사이트의 뼈대(HTML)와 디자인(CSS)은 완벽하지만, 화면에 뜨는 날씨와 공기 질 데이터는 가짜(샘플 데이터)입니다. 여러분의 '통신 마법'으로 이 웹사이트에 진짜 생명력을 불어넣어 주세요!

---

## 🎯 여러분의 최종 목표 (Mission Goal)
**`js/script.js` 파일의 123번째 줄** 근처에 있는 가짜 데이터(`setTimeout`) 부분을 찾아 모두 지우고, 여러분이 배운 `fetch` 마법을 사용해서 **실제 기상청과 에어코리아의 데이터**를 가져와 화면에 연결하세요!

## 🤖 강력한 'AI 요원' 소환 및 활용법
이 폴더(`smart-guide-web`)에는 여러분을 도울 **도로랜드 AI 요원**이 숨어있습니다! (Cursor, Antigravity 등의 AI 에디터를 통해 폴더를 열면 자동으로 활성화됩니다.)

> ⚠️ **주의사항:** AI에게 "정답 코드 다 짜줘!"라고 냅다 명령하지 마세요! 진정한 요원이라면 AI를 '짝꿍(페어 프로그래머)'처럼 활용해야 합니다.

*   **💡 힌트 물어보기:** *"기상청 날씨 데이터 가져오고 싶은데, fetch 코드 어떻게 시작하더라?"*
*   **🐛 에러 해결하기:** 화면에 데이터가 안 뜰 때는 브라우저에서 `F12`를 누르고, 콘솔(Console) 창에 뜬 빨간색 에러 메시지를 복사해서 AI에게 물어보세요. *"이런 에러가 나는데 원인이 뭘까?"*
*   **🎨 내 맘대로 꾸미기:** *"나는 배경화면을 우주 테마로 바꾸고 싶어! CSS 코드 좀 도와줘"* 라고 말해보세요. AI가 멋진 코파일럿이 되어줄 겁니다.

## 🚀 프로젝트 실행 방법 (작전 화면 띄우기)
별도의 복잡한 설치나 서버가 필요하지 않습니다! 
1. 내 컴퓨터 폴더에 있는 **`index.html` 파일을 마우스로 더블 클릭(빠르게 두 번 클릭)** 하세요.
2. 크롬(Chrome)이나 엣지(Edge) 같은 웹 브라우저가 열리면서 작전 화면이 나타납니다.
3. 요원의 코드가 수정될 때마다 브라우저에서 **새로고침(F5)**을 누르면 변경된 작전 화면을 바로 확인할 수 있습니다.

## 🏆 보너스 도전 과제 (Bonus Missions)
기본 미션을 완수했다면, 아래의 심화 작전에도 도전해 보세요!
1.  **나만의 테마 적용:** 배경 이미지, 버튼 색상, 글씨체를 내가 좋아하는 게임이나 영화 테마로 완전히 바꿔보기!
2.  **새로운 공공데이터 추가:** 공공데이터포털(`data.go.kr`)에서 맛집, 교통정보 등 새로운 API를 찾아 AI 요원과 함께 새로운 화면을 추가해 보기!
3.  **내 작품 배포하기:** AI 요원에게 *"이거 내 친구들한테 링크로 보여주고 싶은데, 어떻게 무료로 배포해?"* 라고 물어보고 전 세계에 내 웹사이트를 공개해 보기!

---
*행운을 빕니다, 요원! 멋진 스마트 가이드를 기대하겠습니다!* 😎
